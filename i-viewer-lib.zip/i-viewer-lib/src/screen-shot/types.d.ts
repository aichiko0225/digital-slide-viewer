export interface ScreenShotOptions {
  containOverlay?: boolean
}
