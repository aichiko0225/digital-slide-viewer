import type * as OverlayManagerTypes from '../types'
import type { Options } from './base'
import { DRAW_MODE } from '@/utils/constants'
import Arrow from './arrow'
import Circle from './circle'
import Ellipse from './ellipse'
import Polygon from './polygon'
import Rect from './rect'
import Ruler from './ruler'

/**
 * 形状工厂类
 * 负责创建不同类型的形状
 */
export default class ShapeFactory {
  public static createShape(
    type: OverlayManagerTypes.DrawMode,
    options: Options,
    point: OverlayManagerTypes.Point,
  ): OverlayManagerTypes.Shape | null {
    switch (type) {
      case DRAW_MODE.Circle:
        return new Circle(options, point)
      case DRAW_MODE.Rect:
        return new Rect(options, point)
      case DRAW_MODE.Ellipse:
        return new Ellipse(options, point)
      case DRAW_MODE.Arrow:
        return new Arrow(options, point)
      case DRAW_MODE.Polygon:
        return new Polygon(options, point)
      case DRAW_MODE.Ruler:
        return new Ruler(options, point)
      default:
        return null
    }
  }
}
