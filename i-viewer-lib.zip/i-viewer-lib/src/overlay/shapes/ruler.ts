import type * as OverlayManagerTypes from '../types'
import Konva from 'konva'
import { DRAW_MODE } from '@/utils/constants'
import BaseShape, { type Options } from './base'

export default class Ruler extends BaseShape {
  _mainShape: Konva.Arrow

  constructor(options: Options, point: OverlayManagerTypes.Point) {
    super(options)
    this._mainShape = this._createShape(point)
    this._startPoint = point
    this._layer.add(this._mainShape)
  }

  _createShape(point: OverlayManagerTypes.Point) {
    const shape = new Konva.Arrow({
      points: [point.x, point.y],
      pointerAtBeginning: true,
      pointerLength: 0,
      pointerWidth: (this._shapeOptions.strokeWidth * 5) / this._stage.scaleX(),
      fill: this._shapeOptions.stroke,
      stroke: this._shapeOptions.stroke,
      strokeWidth: this._shapeOptions.strokeWidth,
      hitStrokeWidth: this._shapeOptions.strokeWidth * 5,
      strokeScaleEnabled: false,
      draggable: true,
      attrs: {
        measurement: {
          shapeType: DRAW_MODE.Ruler,
          labelTag: this._labelOptions.tag,
          description: this._labelOptions.description,
          realLength: 0,
        },
      },
    })
    return shape
  }

  _updateShape(point: OverlayManagerTypes.Point) {
    this._mainShape.points([this._startPoint.x, this._startPoint.y, point.x, point.y])
  }

  _completeShape(point: OverlayManagerTypes.Point) {
    this._updateShape(point)
  }
}
