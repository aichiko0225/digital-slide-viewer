import type * as OverlayManagerTypes from '../types'
import Konva from 'konva'
import { DRAW_MODE } from '@/utils/constants'
import BaseShape, { type Options } from './base'

export default class Rect extends BaseShape {
  _mainShape: Konva.Rect

  constructor(options: Options, point: OverlayManagerTypes.Point) {
    super(options)
    this._mainShape = this._createShape(point)
    this._startPoint = point
    this._layer.add(this._mainShape)
  }

  _createShape(point: OverlayManagerTypes.Point) {
    const shape = new Konva.Rect({
      x: point.x,
      y: point.y,
      width: 0,
      height: 0,
      draggable: true,
      stroke: this._shapeOptions.stroke,
      strokeWidth: this._shapeOptions.strokeWidth,
      strokeScaleEnabled: false,
      attrs: {
        measurement: {
          shapeType: DRAW_MODE.Rect,
          labelTag: this._labelOptions.tag,
          description: this._labelOptions.description,
          realWidth: 0,
          realHeight: 0,
          realArea: 0,
          realPerimeter: 0,
        },
      },
    })
    return shape
  }

  _updateShape(point: OverlayManagerTypes.Point) {
    this._mainShape
      .width(point.x - this._mainShape.x())
      .height(point.y - this._mainShape.y())
  }

  _completeShape(point: OverlayManagerTypes.Point) {
    this._updateShape(point)
  }
}
