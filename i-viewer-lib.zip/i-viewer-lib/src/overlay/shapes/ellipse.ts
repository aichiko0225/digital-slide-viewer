import type * as OverlayManagerTypes from '../types'
import Konva from 'konva'
import { DRAW_MODE } from '@/utils/constants'
import { getCenterPoint, getDistanceX, getDistanceY } from '../utils'
import BaseShape, { type Options } from './base'

export default class Ellipse extends BaseShape {
  _mainShape: Konva.Ellipse

  constructor(options: Options, point: OverlayManagerTypes.Point) {
    super(options)
    this._mainShape = this._createShape(point)
    this._startPoint = point
    this._layer.add(this._mainShape)
  }

  _createShape(point: OverlayManagerTypes.Point) {
    const shape = new Konva.Ellipse({
      x: point.x,
      y: point.y,
      radiusX: 0,
      radiusY: 0,
      stroke: this._shapeOptions.stroke,
      strokeWidth: this._shapeOptions.strokeWidth,
      strokeScaleEnabled: false,
      draggable: true,
      attrs: {
        measurement: {
          shapeType: DRAW_MODE.Ellipse,
          labelTag: this._labelOptions.tag,
          description: this._labelOptions.description,
          realRadiusX: 0,
          realRadiusY: 0,
          realArea: 0,
          realPerimeter: 0,
        },
      },
    })
    return shape
  }

  _updateShape(point: OverlayManagerTypes.Point) {
    const distanceX = getDistanceX(point, this._startPoint)
    const distanceY = getDistanceY(point, this._startPoint)
    const centerPoint = getCenterPoint(point, this._startPoint)
    this._mainShape.position(centerPoint).radiusX(distanceX / 2).radiusY(distanceY / 2)
  }

  _completeShape(point: OverlayManagerTypes.Point) {
    this._updateShape(point)
  }
}
