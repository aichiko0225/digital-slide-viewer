import type * as OverlayManagerTypes from '../types'
import Konva from 'konva'
import { DRAW_MODE } from '@/utils/constants'
import { getCenterPoint, getDistance } from '../utils'
import BaseShape, { type Options } from './base'

export default class Circle extends BaseShape {
  _mainShape: Konva.Circle

  constructor(options: Options, point: OverlayManagerTypes.Point) {
    super(options)
    this._mainShape = this._createShape(point)
    this._startPoint = point
    this._layer.add(this._mainShape)
  }

  _createShape(point: OverlayManagerTypes.Point) {
    const shape = new Konva.Circle({
      x: point.x,
      y: point.y,
      radius: 0,
      stroke: this._shapeOptions.stroke,
      strokeWidth: this._shapeOptions.strokeWidth,
      strokeScaleEnabled: false,
      draggable: true,
      attrs: {
        measurement: {
          shapeType: DRAW_MODE.Circle,
          labelTag: this._labelOptions.tag,
          description: this._labelOptions.description,
          realRadius: 0,
          realCircumference: 0,
          realArea: 0,
        },
      },
    })
    return shape
  }

  _updateShape(point: OverlayManagerTypes.Point) {
    const distance = getDistance(point, this._startPoint)
    const centerPoint = getCenterPoint(point, this._startPoint)
    this._mainShape.position(centerPoint).radius(distance / 2)
  }

  _completeShape(point: OverlayManagerTypes.Point) {
    this._updateShape(point)
  }
}
