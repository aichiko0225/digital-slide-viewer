/// <reference types="vite/client" />
/// <reference path="./types/index.d.ts" />
