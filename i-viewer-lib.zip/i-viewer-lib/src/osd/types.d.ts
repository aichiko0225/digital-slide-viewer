export interface OsdOptions extends OpenSeadragon.Options {

}
