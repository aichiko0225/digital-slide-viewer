import type * as OsdManagerTypes from './types.d'
import OpenSeadragon from 'openseadragon'

// 导出类型
export type { OsdOptions } from './types.d'

export class OsdManager {
  private _viewer: OpenSeadragon.Viewer

  constructor(config: OsdManagerTypes.OsdOptions) {
    this._viewer = this._init(config)
  }

  private _init(config: OsdManagerTypes.OsdOptions) {
    const osd = new OpenSeadragon.Viewer({
      showNavigator: true,
      showNavigationControl: false,
      navigatorPosition: 'TOP_LEFT',
      minZoomImageRatio: 0.5,
      maxZoomPixelRatio: 2,
      zoomPerClick: 2,
      zoomPerScroll: 2,
      gestureSettingsMouse: {
        clickToZoom: false,
        dblClickToZoom: false,
        flickEnabled: true,
        flickMomentum: 0.1,
      },
      ...config,
    })
    return osd
  }

  public getViewer() {
    return this._viewer
  }

  public destroy() {
    this._viewer.destroy()
  }
}
