import type { DrawMode, LabelOptions } from 'i-viewer-lib'
import { Constants, OsdManager, OverlayManager, ScreenShotManager } from 'i-viewer-lib'

const iMapInfo = {
  uuid: 1749537279716012,
  createTime: 1744626384968,
  path: 'E:\\TMAP\\SLICEID-20250324112235.TMAP',
  name: 'SLICEID-20250324112235.TMAP',
  width: 264413,
  height: 120675,
  scale: 40,
  macroExist: true,
  relativePath: 'E:\\TMAP',
  labelInfo: null,
  size: 2016141323,
  type: 'tmap',
  state: 'unknown',
  version: '6.1',
  focusNums: 0,
  saveScale: 59,
  slideType: 0,
  pixelSize: 0.0069199996,
  tileSize: 256,
}

const osd = new OsdManager({
  id: 'app',
  tileSources: {
    width: 264413,
    height: 120675,
    tileSize: 256,
    getTileUrl: (level: number, col: number, row: number) => {
      return `http://localhost:48448/iviewerservice/oceanview/previewocean/1749781270550021/0/${level}/${col}_${row}.jpg`
    },
  },
})

const overlay = new OverlayManager(osd, {
  shapeOptions: {
    strokeWidth: 2,
    stroke: '#000',
  },
  labelOptions: {
    fontSize: 12,
    pixelSize: iMapInfo.pixelSize,
    editDescriptionEvent: (description: string) => {
      // eslint-disable-next-line no-alert
      const newDescription = window.prompt('请输入描述', description)
      if (newDescription) {
        overlay.setLabelOptions({
          description: newDescription,
        })
      }
    },
  },
})

const screenShotManager = new ScreenShotManager(osd, overlay, {
  containOverlay: true,
})

$('#toolbar').on('click', (e) => {
  overlay.setDrawMode(e.target.getAttribute('type') as DrawMode)
})

$('#change-shape').on('click', (e) => {
  if (e.target.getAttribute('target') === 'label') {
    if (e.target.getAttribute('type') === 'alwaysVisible') {
      overlay.setLabelOptions({
        alwaysVisible: e.target.getAttribute('data') === '1',
      })
    }
    else if (e.target.getAttribute('type') === 'measurement') {
      overlay.setLabelOptions({
        [`${Constants.LABEL_TYPE.MEASUREMENT}Visible`]: e.target.getAttribute('data') === '1',
      })
    }
    else if (e.target.getAttribute('type') === 'tag') {
      overlay.setLabelOptions({
        [`${Constants.LABEL_TYPE.TAG}Visible`]: e.target.getAttribute('data') === '1',
      })
    }
    else if (e.target.getAttribute('type') === 'description') {
      overlay.setLabelOptions({
        [`${Constants.LABEL_TYPE.DESCRIPTION}Visible`]: e.target.getAttribute('data') === '1',
      })
    }
    else {
      overlay.setLabelOptions({
        [e.target.getAttribute('type') as keyof LabelOptions]: e.target.getAttribute('data'),
      })
    }
  }
  if (e.target.getAttribute('target') === 'shape') {
    overlay.setShapeOptions({
      [e.target.getAttribute('type') as keyof LabelOptions]: e.target.getAttribute('data') === '1',
    })
  }
})

$('#screenshot').on('click', () => {
  screenShotManager.takeScreenshot()
})
